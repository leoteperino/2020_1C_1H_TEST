#ifndef UTN_H_
#define UTN_H_

int getInt(char mensaje[]);
float getFloat(char mensaje[]);
char getChar(char mensaje[]);
char getNumeroAleatorio(int desde , int hasta, int iniciar);


#endif /* UTN_H_ */
