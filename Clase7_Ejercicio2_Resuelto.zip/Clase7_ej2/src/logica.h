/*
 * logica.h
 *
 *  Created on: Apr 18, 2020
 *      Author: Mauro
 */

#ifndef LOGICA_H_
#define LOGICA_H_

int imprimeArrayFlotante(float* pArray, int longitud);
int initArrayFlotante(float* pArray, int longitud,float valorInicial);
int cargarTemperatura(float* pArray, int longitud);

#endif /* LOGICA_H_ */
