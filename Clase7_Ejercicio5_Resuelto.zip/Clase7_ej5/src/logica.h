/*
 * logica.h
 *
 *  Created on: Apr 18, 2020
 *      Author: Mauro
 */

#ifndef LOGICA_H_
#define LOGICA_H_

int borrarImpares(int* pArray, int limite);
int imprimirNumeros(int* pArray, int limite);
int solicitarNumeros(int* pArray, int limite);
int ordenarNumeros(int* pArray, int limite);

#endif /* LOGICA_H_ */
