/*
 * logica.h
 *
 *  Created on: Apr 18, 2020
 *      Author: Mauro
 */

#ifndef LOGICA_H_
#define LOGICA_H_

#endif /* LOGICA_H_ */
